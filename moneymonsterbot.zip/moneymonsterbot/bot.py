﻿import telebot
from telebot.types import Message
import json
import os

# Bot token
TOKEN = '7616383755:AAHQRqDLtnFg5m1NYWtXhy8NSFuhqg2ZSfM'
bot = telebot.TeleBot(TOKEN)

# Load or create user data
if not os.path.exists("users.json"):
    with open("users.json", "w") as f:
        json.dump({}, f)


def load_users():
    with open("users.json", "r") as f:
        return json.load(f)


def save_users(data):
    with open("users.json", "w") as f:
        json.dump(data, f, indent=2)


# Create keyboard markup
def get_main_keyboard():
    keyboard = telebot.types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True, one_time_keyboard=False)
    buttons = [
        telebot.types.KeyboardButton('💰 Wallet'),
        telebot.types.KeyboardButton('🎁 Ads'),
        telebot.types.KeyboardButton('👥 Menu'),
        telebot.types.KeyboardButton('❌ Back')
    ]
    keyboard.add(*buttons)
    return keyboard

# /start command with referral system
@bot.message_handler(commands=['start'])
def send_welcome(message: Message):
    users = load_users()
    user_id = str(message.from_user.id)
    username = message.from_user.username or ""
    referral_id = None

    if len(message.text.split()) > 1:
        referral_id = message.text.split()[1]

    if user_id not in users:
        users[user_id] = {
            "balance": 1000,
            "transactions": ["Signup Bonus +1000 MMTD"],
            "referrals": [],
            "username": username
        }

        if referral_id and referral_id in users and referral_id != user_id:
            users[referral_id]["balance"] += 500
            users[referral_id]["transactions"].append(
                f"Referral Bonus +500 MMTD (from {user_id})")
            users[referral_id]["referrals"].append(user_id)

        save_users(users)
        bot.reply_to(
            message,
            "Welcome to Money Monster!\nYou received 1000 MMTD as signup bonus.",
            reply_markup=get_main_keyboard()
        )
    else:
        bot.reply_to(
            message,
            "You already have an account. Use /wallet to check your balance.")


# /wallet command
@bot.message_handler(commands=['wallet'])
def show_wallet(message: Message):
    users = load_users()
    user_id = str(message.from_user.id)

    if user_id in users:
        data = users[user_id]
        tx = "\n".join(data['transactions'][-5:])
        bot.reply_to(
            message,
            f"Your Wallet\nBalance: {data['balance']} MMTD\n\nLast Transactions:\n{tx}",
            reply_markup=get_main_keyboard()
        )
    else:
        bot.reply_to(message, "You are not registered. Use /start to join.")


# /referral command
@bot.message_handler(commands=['referral'])
def show_referral(message: Message):
    user_id = str(message.from_user.id)
    bot_username = "MoneyMonsterMMTD_bot"  # Replace with your actual bot username
    link = f"https://t.me/{bot_username}?start={user_id}"
    bot.reply_to(message, f"Your referral link:\n{link}")


# /ads command - watch ad and earn
@bot.message_handler(commands=['ads'])
def watch_ad(message: Message):
    users = load_users()
    user_id = str(message.from_user.id)

    if user_id in users:
        users[user_id]['balance'] += 5
        users[user_id]['transactions'].append("Watched Ad +5 MMTD")
        save_users(users)
        
        # Create inline keyboard with the channel link
        keyboard = telebot.types.InlineKeyboardMarkup()
        channel_button = telebot.types.InlineKeyboardButton(text="📢 Join Our Channel", url="https://t.me/mmsocialnetwork")
        keyboard.add(channel_button)
        
        bot.reply_to(
            message,
            "💰 You earned 5 MMTD!\n\n📱 Join our channel for more rewards:",
            reply_markup=keyboard
        )
    else:
        bot.reply_to(message, "Register with /start first.")


# /send command - transfer tokens to another user
@bot.message_handler(commands=['send'])
def send_tokens(message: Message):
    users = load_users()
    user_id = str(message.from_user.id)
    args = message.text.split()

    if len(args) != 3:
        bot.reply_to(message, "Usage: /send @username amount")
        return

    receiver_username = args[1].lstrip('@')
    try:
        amount = int(args[2])
    except ValueError:
        bot.reply_to(message, "Invalid amount.")
        return

    if user_id not in users or users[user_id]['balance'] < amount:
        bot.reply_to(message, "Insufficient balance or user not found.")
        return

    # Find receiver by username
    receiver_id = None
    for uid, data in users.items():
        if data.get('username') == receiver_username:
            receiver_id = uid
            break

    if receiver_id:
        users[user_id]['balance'] -= amount
        sender_username = users[user_id].get('username', 'unknown')
        users[user_id]['transactions'].append(
            f"Sent -{amount} MMTD to @{receiver_username}")

        users[receiver_id]['balance'] += amount
        users[receiver_id]['transactions'].append(
            f"Received +{amount} MMTD from @{sender_username}")

        save_users(users)
        bot.reply_to(message, f"Sent {amount} MMTD to @{receiver_username}")
    else:
        bot.reply_to(message, "Receiver not found or not registered.")


# /help command
@bot.message_handler(commands=['help'])
def help_command(message: Message):
    bot.reply_to(
        message, """
Welcome to Money Monster Bot (MMTD)!

/start - Register & claim 1000 MMTD  
/wallet - View your balance & transactions  
/referral - Get your referral link  
/ads - Watch ad & earn 5 MMTD  
/send @username amount - Send tokens  
/help - Show this message
""")


# Handle button presses
@bot.message_handler(func=lambda message: message.text in ['💰 Wallet', '🎁 Ads', '👥 Referral', '❓ Help'])
def button_handler(message):
    if message.text == '💰 Wallet':
        show_wallet(message)
    elif message.text == '🎁 Ads':
        watch_ad(message)
    elif message.text == '👥 Referral':
        show_referral(message)
    elif message.text == '❓ Help':
        help_command(message)

# Start the bot with error handling
def start_bot():
    try:
        print("Bot starting...")
        bot.infinity_polling(timeout=10, long_polling_timeout=5)
    except Exception as e:
        print(f"Bot error occurred: {e}")
        start_bot()  # Restart bot on error

start_bot()